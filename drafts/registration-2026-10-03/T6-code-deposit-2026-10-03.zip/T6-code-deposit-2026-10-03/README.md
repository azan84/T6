# T6 — code and frozen protocol deposited with the pre-registration (2026-10-03)

Boundary-condition tuning and topological segmentation error in reduced-order coronary FFR: a pre-registered
three-protocol ablation at the 0.80 decision threshold.

This deposit freezes the analysis code, the cohort and the analysis plan **before** the A/B/C ablation is run.
It accompanies an OSF preregistration (link added in a later version of this record).

## Contents
- `code/` — 0D coronary FFR model (`zerod_ffr.py`), error injection (`error_types.py`), severity sweep and cohort
  selection (`severity_sweep.py`), ablation (`ablation.py`), noise floor / detector negatives (`negatives.py`),
  3D case export (`export_cfd_case.py`), as-meshed radius ingestion (`ingest_cfd_radius.py`) and the 0D–3D comparison
  (`m1_zerod_vs_3d.py`).
- `protocol/` — `STATISTICS-PLAN.md` (v1.0), `SEVERITY-SWEEP-SPEC.md`, `CFD-ARM-SPEC.md` (v0.2), `DETECTOR-SPEC.md`
  (v0.2), the frozen cohort (150 instances), the frozen 3D subset (30) and the SHA-256 manifest.
- `results/` — the two baseline files the manifest covers (prevalence check, severity sweep). No ablation results.
- `registration/` — the pre-lodging addendum and the P5 pilot selection rule.

## Verify
From the deposit root: `shasum -a 256 -c protocol/COHORT-FROZEN-2026-09-18.sha256` (15 entries, all OK).

## Data
Not included. ImageCAS-X annotation layer, DOI 10.5281/zenodo.21887809 (v1, CC BY 4.0). Scripts take the dataset
root as their first argument.

## Environment
Python 3.14, packages pinned in `requirements.txt`.
